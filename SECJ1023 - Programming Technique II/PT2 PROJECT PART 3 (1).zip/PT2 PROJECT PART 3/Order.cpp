#include "Order.h"
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <iomanip>
using namespace std;

Order::Order() {
    itemCount = 0; total = 0;
    deliveryStatus = "Preparing";
    payRecord = nullptr;
    orderId = nextId++;
}

Order::~Order() { delete payRecord; }

void Order::setCustomerInfo(CustomerInfo info) { customer = info; }

bool Order::addOrMergeItem(string name, double price, int q) {
    // Check if item already exists
    for (int i = 0; i < itemCount; i++) {
        if (items[i].getItemName() == name) {
            items[i].addQuantity(q);
            total += price * q;
            return true; // merged
        }
    }
    // Not found — add new entry
    if (itemCount < MAX_ORDER_ITEMS) {
        items[itemCount++] = OrderItem(name, price, q);
        total += price * q;
        return true;
    }
    return false; // order full
}

bool Order::checkout() {
    payRecord = new Payment(total);
    payRecord->selectPaymentMethod();
    return payRecord->process();
}

void Order::updateTracking() {
    string statuses[] = {"Preparing", "Kitchen Cooking", "On the way", "Arrived"};
    deliveryStatus = statuses[rand() % 4];
}

void Order::display(bool showTracking) const {
    cout << "\n------------------------------------------" << endl;
    cout << "ORDER ID: #" << orderId << endl;
    if(showTracking) cout << "STATUS: [" << deliveryStatus << "]";
    cout << "\n------------------------------------------" << endl;
    customer.display();
    for(int i = 0; i < itemCount; i++) items[i].printLine();
    cout << "\nTOTAL: RM " << fixed << setprecision(2) << total << endl;
    cout << "------------------------------------------" << endl;
}

int Order::getOrderId() const { return orderId; }

double Order::getTotal() const { return total; }

int Order::nextId = 1001;