#ifndef DRINKITEM_H
#define DRINKITEM_H
#include <string>
#include "MenuItem.h"
using namespace std;

class DrinkItem : public MenuItem {
    private:
        bool isCold;
    public:
        DrinkItem();
        DrinkItem(int i, string n, double p, bool cold);
        bool getIsCold() const;
        void display() const;
};

#endif