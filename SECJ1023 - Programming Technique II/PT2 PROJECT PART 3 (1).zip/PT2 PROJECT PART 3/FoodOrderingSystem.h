#ifndef FOOD_ORDERING_SYSTEM_H
#define FOOD_ORDERING_SYSTEM_H
#include <string>
#include "FoodItem.h"
#include "DrinkItem.h"
#include "Order.h"
#include "Feedback.h"

using namespace std;

const int MAX_MENU = 50;
const int MAX_ORDERS = 50;
const int MAX_FEEDBACKS = 50;

class FoodOrderingSystem {
    private:
        FoodItem  foodMenu[MAX_MENU];    // separate array for food
        DrinkItem drinkMenu[MAX_MENU];   // separate array for drinks
        int foodCount;
        int drinkCount;
        Order* history[MAX_ORDERS];
        int orderCount;
        Feedback feedbacks[MAX_FEEDBACKS];
        int feedbackCount;
        Order* current;
    public:
        FoodOrderingSystem();
        ~FoodOrderingSystem();
        void initializeMenu();
        void displayMenu();
        void startOrdering();
        void doCheckout();
        void trackOrders();
        void addFeedback();
        void showFeedbacks();
};

#endif