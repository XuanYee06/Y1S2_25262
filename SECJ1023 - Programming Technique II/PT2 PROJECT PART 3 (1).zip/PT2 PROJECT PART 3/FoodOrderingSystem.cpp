#include "FoodOrderingSystem.h"
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <iomanip>
using namespace std;

FoodOrderingSystem::FoodOrderingSystem()
    : foodCount(0), drinkCount(0), orderCount(0), feedbackCount(0), current(nullptr) {
    for(int i = 0; i < MAX_ORDERS; i++) history[i] = nullptr;
    srand(time(0));
    initializeMenu();
}
FoodOrderingSystem::~FoodOrderingSystem() {
    for(int i = 0; i < orderCount; i++) delete history[i];
    if(current) delete current;
}
void FoodOrderingSystem::initializeMenu() {
    foodMenu[foodCount++] = FoodItem(1,  "Nasi Lemak Chicken",        7.50, "Main");
    foodMenu[foodCount++] = FoodItem(2,  "Chicken Rice",              9.00, "Main");
    foodMenu[foodCount++] = FoodItem(3,  "Wonton Noodle Soup",        8.50, "Main");
    foodMenu[foodCount++] = FoodItem(4,  "Beef Burger Special",      12.00, "Main");
    foodMenu[foodCount++] = FoodItem(5,  "Chicken Pizza (R)",        12.00, "Main");
    foodMenu[foodCount++] = FoodItem(6,  "Penang Laksa",              7.00, "Main");
    foodMenu[foodCount++] = FoodItem(7,  "Penang Hokkien Mee",        7.00, "Main");
    foodMenu[foodCount++] = FoodItem(8,  "Char Kuey Teow",            7.00, "Main");
    foodMenu[foodCount++] = FoodItem(9,  "Cheesy Fries",              5.50, "Snack");
    foodMenu[foodCount++] = FoodItem(10, "Fried Chicken (2 pcs)",     7.00, "Snack");
    foodMenu[foodCount++] = FoodItem(11, "Roti Canai",                3.50, "Snack");
    foodMenu[foodCount++] = FoodItem(12, "Tosai",                     4.50, "Snack");
    foodMenu[foodCount++] = FoodItem(13, "Curry Puff Sardin (2 pcs)", 4.00, "Snack");
    foodMenu[foodCount++] = FoodItem(14, "Sundae Cone",               4.00, "Dessert");
    foodMenu[foodCount++] = FoodItem(15, "Burnt Cheese Cake (1 pcs)", 7.00, "Dessert");
    foodMenu[foodCount++] = FoodItem(16, "Apam Balik (2 pcs)",        4.00, "Dessert");

    drinkMenu[drinkCount++] = DrinkItem(17, "Teh Tarik Panas", 3.00, false);
    drinkMenu[drinkCount++] = DrinkItem(18, "Teh Tarik Ais",   3.00, true);
    drinkMenu[drinkCount++] = DrinkItem(19, "Iced Lemon Tea",  4.00, true);
    drinkMenu[drinkCount++] = DrinkItem(20, "Cendol",          4.00, true);
}
void FoodOrderingSystem::displayMenu() {
    cout << "\n======= MENU =======" << endl;
    cout << "\n-- Food --" << endl;
    for(int i = 0; i < foodCount; i++) foodMenu[i].display();
    cout << "\n-- Drinks --" << endl;
    for(int i = 0; i < drinkCount; i++) drinkMenu[i].display();
    cout << endl;
}
void FoodOrderingSystem::startOrdering() {
	if (current && current->getTotal() > 0) {
        cout << "\nYou have an active order. (C)ontinue or (N)ew? ";
        char c; cin >> c;
        if (c == 'N' || c == 'n') {
            delete current;
            current = new Order();
        }
        // else fall through and reuse current
    }
	else if (!current) {
        current = new Order();
    }
    displayMenu();
    while(true) {
        int id, qty;
        cout << "Enter Menu ID (0 to stop): ";
        cin >> id;
        if(id == 0) break;

        // search food array
        bool found = false;
        for(int i = 0; i < foodCount; i++) {
            if(foodMenu[i].getId() == id) {
                do {
                    cout << "Qty: "; cin >> qty;
                    if(qty <= 0) cout << "Invalid quantity." << endl << endl;
                } while(qty <= 0);
                current->addOrMergeItem(foodMenu[i].getName(), foodMenu[i].getPrice(), qty);
                found = true;
                break;
            }
        }
        // search drink array
        if(!found) {
            for(int i = 0; i < drinkCount; i++) {
                if(drinkMenu[i].getId() == id) {
                    do {
                        cout << "Qty: "; cin >> qty;
                        if(qty <= 0) cout << "Invalid quantity." << endl << endl;
                    } while(qty <= 0);
                    current->addOrMergeItem(drinkMenu[i].getName(), drinkMenu[i].getPrice(), qty);
                    found = true;
                    break;
                }
            }
        }
        if(!found) cout << "Invalid Food ID" << endl;
        cout << endl;
    }
}
void FoodOrderingSystem::doCheckout() {
    if(!current || current->getTotal() == 0) {
        cout << "\n[!] Please order something first." << endl;
        return;
    }
    CustomerInfo info;
    info.inputInfo();
    current->setCustomerInfo(info);
    if(current->checkout()) {
        history[orderCount++] = current;
        cout << "\n[Success] Receipt Generated:" << endl;
        history[orderCount-1]->display(true);
        current = nullptr;
    }
}
void FoodOrderingSystem::trackOrders() {
    if(orderCount == 0) { cout << "\n[!] No active delivery." << endl; return; }
    cout << "\n======= LIVE TRACKING =======" << endl;
    for(int i = 0; i < orderCount; i++) {
        history[i]->updateTracking();
        history[i]->display(true);
    }
}
void FoodOrderingSystem::addFeedback() {
    if(orderCount == 0){
    	cout << "\n[!] No orders to rate." << endl;
    	return;
	}
	int oid = history[orderCount - 1]->getOrderId();
	// Check if this order already has feedback
    for (int i = 0; i < feedbackCount; i++) {
        if (feedbacks[i].getId() == oid) {
            cout << "[!] You have already rated order #" << oid << "." << endl;
            return;
        }
    }
    Feedback fb(history[orderCount-1]->getOrderId());
    fb.input();
    feedbacks[feedbackCount++] = fb;
}
void FoodOrderingSystem::showFeedbacks() {
    if(feedbackCount == 0) cout << "\n[!] No feedback yet." << endl;
    for(int i = 0; i < feedbackCount; i++) feedbacks[i].display();
}