#ifndef MENUITEM_H
#define MENUITEM_H
#include <string>
using namespace std;

class MenuItem {
    protected:
        int id;
        string name;
        double price;
    public:
        MenuItem();
        MenuItem(int i, string n, double p);
        int getId() const;
        string getName() const;
        double getPrice() const;
        void display() const;
};

#endif