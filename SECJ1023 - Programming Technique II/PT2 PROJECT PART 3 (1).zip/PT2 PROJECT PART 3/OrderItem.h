#ifndef ORDERITEM_H
#define ORDERITEM_H
#include <string>
using namespace std;

class OrderItem {
    private:
        string itemName;
        double itemPrice;
        int quantity;
    public:
        OrderItem();
        OrderItem(string n, double p, int q);
        string getItemName() const;
        double getSubtotal() const;
        void addQuantity(int q);
        void printLine() const;
        int getQuantity() const;
};

#endif