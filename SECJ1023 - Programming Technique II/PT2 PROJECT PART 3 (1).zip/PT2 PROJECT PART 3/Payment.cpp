#include "Payment.h"
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

Payment::Payment(double a) { amount = a; }

void Payment::selectPaymentMethod() {
    int choice;
    cout << "\n1. Card | 2. E-Wallet | 3. Cash\nSelect Payment: ";
    cin >> choice;
    if(choice == 1) { method = "Card"; cout << "Card No: "; cin >> details; }
    else if(choice == 2) { method = "E-Wallet"; cout << "Wallet ID: "; cin >> details; }
    else { method = "Cash"; details = "N/A"; }
    cout << endl;
}

bool Payment::process() {
    cout << ">> Paying RM" << amount << " via " << method << "... Done!" << endl;
    return true;
}

string Payment::getMethod() const { return method; }