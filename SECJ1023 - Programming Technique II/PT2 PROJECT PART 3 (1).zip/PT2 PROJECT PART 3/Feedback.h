#ifndef FEEDBACK_H
#define FEEDBACK_H
#include <string>
using namespace std;

class Feedback {
    private:
        int id;
        int rate;
        string msg;
    public:
        Feedback();
        Feedback(int);
        int getId() const;
        void input();
        void display() const;
};

#endif