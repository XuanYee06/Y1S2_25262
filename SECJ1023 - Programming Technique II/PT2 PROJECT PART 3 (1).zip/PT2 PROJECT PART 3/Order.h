#ifndef ORDER_H
#define ORDER_H
#include <string>
#include "CustomerInfo.h"
#include "OrderItem.h"
#include "Payment.h"
using namespace std;

const int MAX_ORDER_ITEMS = 50;

class Order {
    private:
        static int nextId;
        int orderId;
        CustomerInfo customer;
        OrderItem items[MAX_ORDER_ITEMS];
        int itemCount;
        double total;
        string deliveryStatus;
        Payment* payRecord;
    public:
        Order();
        ~Order();
        void setCustomerInfo(CustomerInfo info);
		bool addOrMergeItem(string name, double price, int q);
        bool checkout();
        void updateTracking();
        void display(bool showTracking = false) const;
        int getOrderId() const;
        double getTotal() const;
};

#endif