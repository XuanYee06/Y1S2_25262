#include <iostream>
#include <string>
#include "DrinkItem.h"
#include "FoodItem.h"
#include "MenuItem.h"
using namespace std;

int main() {
    // MenuItem, FoodItem, DrinkItem
    FoodItem obj1(1, "Nasi Lemak Chicken", 10, "Snack");
    DrinkItem obj2(2, "Teh Tarik", 5, false);
    
    cout << obj1.getCategory() << endl;
    cout << obj1.getId() << endl;
    cout << obj1.getName() << endl;
    cout << obj1.getPrice() << endl;
    
    cout << obj2.getId() << endl;
    cout << obj2.getIsCold() << endl;
    cout << obj2.getName() << endl;
    cout << obj2.getPrice() << endl;
    
    obj1.display();
    obj2.display();
    
    return 0;
}