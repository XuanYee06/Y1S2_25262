#include <iostream>
#include "FoodOrderingSystem.h"
using namespace std;

int main() {
	// FoodOrderingSystem
    FoodOrderingSystem obj8;
    obj8.startOrdering();
    obj8.doCheckout();
    obj8.trackOrders();
    obj8.addFeedback();
    obj8.showFeedbacks();
    
    return 0;
}