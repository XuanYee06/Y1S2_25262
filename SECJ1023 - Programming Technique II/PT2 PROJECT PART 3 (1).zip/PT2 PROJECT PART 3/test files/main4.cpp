#include <iostream>
#include "Payment.h"
using namespace std;

int main() {
    // Payment
    Payment obj5(37.5);
    obj5.selectPaymentMethod();
    obj5.getMethod();
    obj5.process();
    
    return 0;
}