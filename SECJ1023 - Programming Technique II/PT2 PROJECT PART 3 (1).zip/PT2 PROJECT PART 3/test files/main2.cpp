#include <iostream>
#include "OrderItem.h"
using namespace std;

int main() {
    // OrderItem
    OrderItem obj3("Nasi Lemak Chicken", 7.5, 2);
    cout << obj3.getItemName() << endl;
    cout << obj3.getQuantity() << endl;
    cout << obj3.getSubtotal() << endl;
    
    obj3.printLine();
    
    obj3.addQuantity(3);
    
    cout << obj3.getItemName() << endl;
    cout << obj3.getQuantity() << endl;
    cout << obj3.getSubtotal() << endl;
    
    obj3.printLine();
    
    return 0;
}