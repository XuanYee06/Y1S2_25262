#include <iostream>
#include "Feedback.h"
using namespace std;

int main() {
    // Feedback
    Feedback obj7(1001);
    obj7.getId();
    obj7.input();
    obj7.display();
    
    return 0;
}