#include <iostream>
#include <string>
#include "CustomerInfo.h"
#include "Order.h"
using namespace std;

int main() {
    // CustomerInfo
    CustomerInfo obj4;
    obj4.inputInfo();
    cout << obj4.getName() << endl;
    obj4.display();
    
    // Order
    Order obj6;
    obj6.setCustomerInfo(obj4);
    
    cout << obj6.getOrderId() << endl;
    cout << obj6.getTotal() << endl;
    
    obj6.display(true);
    
    obj6.updateTracking();
    
    obj6.display(true);
    
    return 0;
}