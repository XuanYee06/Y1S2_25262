TITLE LAB 2 QUESTION 5
; AUthor: NG XUAN YEE & CHENG ZHI MIN

include Irvine32.inc
.code
main proc
    MOV DX,0        ; Clear DX
    MOV AX,1000h    ; Load 1000h into AX
    MOV CX, 25h     ; Load 25h into CX
    MUL CX          ; Multiply AX by CX, storing the result in DX:AX
    call dumpregs   ; Display registers
    exit
main endp
end main