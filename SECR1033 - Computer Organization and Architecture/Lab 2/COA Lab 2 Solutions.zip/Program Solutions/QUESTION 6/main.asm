TITLE LAB 2 QUESTION 6
; AUthor: NG XUAN YEE & CHENG ZHI MIN

include Irvine32.inc
.code
main proc
    MOV DX, 0 	    ; Clear DX to form the 16-bit dividend in DX:AX 
    MOV AX, 803h    ; Load the dividend (8003h) into AX 
    MOV BL, 10h 	; Load the divisor (10h) into BL 
    DIV BL          ; Divide DX:AX by BL, whereby AX=quotient & DX=remainder
    call dumpregs   ; Display registers
    exit
main endp
end main