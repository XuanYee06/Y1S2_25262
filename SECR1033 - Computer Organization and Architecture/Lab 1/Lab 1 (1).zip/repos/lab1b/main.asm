TITLE Add and Subtract, Version 2(AddSub2.asm)
; This program adds and subtracts 32 - bit unsigned
; integers and stores the sum in a variable.
; Authors: Cheng Zhi Min, Ng Xuan Yee
; Date: 15 Apr 2026
; Revision: Lab 1 part B
INCLUDE Irvine32.inc
.data
val1 DWORD 10000h
val2 DWORD 40000h
val3 DWORD 20000h
finalVal DWORD ?
.code
main PROC
mov eax, val1
add eax, val2
sub eax, val3
; start with 10000h
; add 40000h
; subtract 20000h
mov finalVal, eax; store the result(30000h)
call DumpRegs; display the registers
exit
main ENDP
END main